import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import Modal from './Modal'
import './assets/css/style.css'

createRoot(document.getElementById('root')).render(
  <>
    <Modal />
  </>,
)
