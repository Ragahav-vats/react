import React, { useState } from 'react'

export default function Modal() {
  const [select,setSelect] = useState(true)

  const view = () =>{
    setSelect(false)
  }

  const hide = () =>{
    setSelect(true)
  }

  return (
    <>
      <header className='main'>
         <button className='primary' onClick={view}>View Cart</button>
      </header>

      <div className={`outer-section ${select ? 'try' : ''}`}>
        <span onClick={hide}>&times;</span>
      </div>
    </>
  )
}
